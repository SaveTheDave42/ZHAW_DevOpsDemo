import * as path from "path-framework/app/path-framework/pathinterface";

// TODO in future versions these classes will be generated from gui model

