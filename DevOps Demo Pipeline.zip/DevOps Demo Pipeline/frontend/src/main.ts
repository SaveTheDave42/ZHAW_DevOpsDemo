import { platformBrowserDynamic } from "./../node_modules/path-framework/node_modules/@angular/platform-browser-dynamic";
import { ExampleAppModule } from "./app/example-app.module";

platformBrowserDynamic().bootstrapModule(ExampleAppModule).catch(err => console.error(err));;
